package pe.edu.upc.trabajoaw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoAwApplicationTests {

	@Test
	void contextLoads() {
	}

}
