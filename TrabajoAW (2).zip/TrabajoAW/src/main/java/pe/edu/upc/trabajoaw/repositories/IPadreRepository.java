package pe.edu.upc.trabajoaw.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upc.trabajoaw.entities.Padre;

public interface IPadreRepository extends JpaRepository<Padre,Integer> {
}
