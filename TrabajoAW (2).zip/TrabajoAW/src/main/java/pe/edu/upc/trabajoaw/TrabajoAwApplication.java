package pe.edu.upc.trabajoaw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoAwApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoAwApplication.class, args);
	}

}
