package pe.edu.upc.trabajoaw.dtos;

public class FraseMotivacionalDTO {
    private int idFraseMotivacional;
    private String frase;

    public int getIdFraseMotivacional() {
        return idFraseMotivacional;
    }

    public void setIdFraseMotivacional(int idFraseMotivacional) {
        this.idFraseMotivacional = idFraseMotivacional;
    }

    public String getFrase() {
        return frase;
    }

    public void setFrase(String frase) {
        this.frase = frase;
    }
}
