package pe.edu.upc.trabajoaw.dtos;

public class RecomendacionDTO {
    private int idRecomendacion;
    private String descripcion;

    public int getIdRecomendacion() {
        return idRecomendacion;
    }
    public void setIdRecomendacion(int idRecomendacion) {
        this.idRecomendacion = idRecomendacion;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}